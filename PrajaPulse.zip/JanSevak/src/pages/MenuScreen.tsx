import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Gamepad2,
  BarChart3,
  GraduationCap,
  Award,
  ArrowUpRight,
  AlertTriangle,
  CloudRain,
  Users,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const MenuScreen: React.FC = () => {
  const navigate = useNavigate();
  const { badges } = useApp();

  const unlockedBadgesCount = badges ? badges.filter((b) => b.isUnlocked).length : 4;

  return (
    <div className="flex-1 flex flex-col px-3.5 sm:px-4 pt-3 pb-12 space-y-4 max-w-2xl mx-auto w-full select-none">
      {/* ========================================================= */}
      {/* 1. TOP DUAL FEATURED BUTTONS (VOLUNTEER & ALERT HALF-HALF) */}
      {/* ========================================================= */}
      <div className="grid grid-cols-2 gap-3 sm:gap-3.5">
        {/* Left Button (Half): Ward Volunteering */}
        <button
          type="button"
          onClick={() => navigate('/vacancies')}
          className="text-left w-full relative overflow-hidden bg-gradient-to-br from-[#0f2d59] via-[#1B6643] to-[#257C53] text-white rounded-3xl p-3.5 sm:p-4 shadow-sm hover:shadow-lg active:scale-[0.98] transition-all duration-300 group cursor-pointer border border-[#1d4e8c]/40 focus:outline-none flex flex-col justify-between min-h-[145px]"
        >
          {/* Subtle Decorative Ambient Glows */}
          <div className="absolute -right-8 -bottom-8 w-28 h-28 bg-white/10 rounded-full blur-xl pointer-events-none group-hover:scale-125 transition-transform" />

          {/* Top Row: Tag & Mini Action Button */}
          <div className="relative z-10 flex items-center justify-between w-full">
            <span className="inline-flex items-center gap-1 text-[9.5px] font-black uppercase tracking-wider bg-white/15 backdrop-blur-xs text-[#A7F3D0] px-2 py-0.5 rounded-full border border-white/10">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-pulse" />
              VOLUNTEER
            </span>
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-white text-[#0f2d59] flex items-center justify-center shadow-xs group-hover:scale-105 group-hover:rotate-6 transition-all">
              <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
            </div>
          </div>

          {/* Text Content */}
          <div className="relative z-10 space-y-1 my-1">
            <h2 className="text-sm sm:text-base font-black tracking-tight text-white leading-tight">
              Cleanups & Tree Drives
            </h2>
            <p className="text-[11px] text-emerald-100/90 leading-snug line-clamp-2">
              Join verified NGO initiatives in Ward 112.
            </p>
          </div>

          {/* Bottom Footer Line */}
          <div className="relative z-10 flex items-center justify-between pt-1.5 border-t border-white/15 text-[10.5px] font-bold text-emerald-200">
            <span>4 Active Drives</span>
            <span className="group-hover:translate-x-0.5 transition-transform">Join →</span>
          </div>
        </button>

        {/* Right Button (Half): Alert & Predictive Analysis */}
        <button
          type="button"
          onClick={() => navigate('/alerts')}
          className="text-left w-full relative overflow-hidden bg-gradient-to-br from-[#7f1d1d] via-[#9a3412] to-[#b45309] text-white rounded-3xl p-3.5 sm:p-4 shadow-sm hover:shadow-lg active:scale-[0.98] transition-all duration-300 group cursor-pointer border border-amber-500/40 focus:outline-none flex flex-col justify-between min-h-[145px]"
        >
          {/* Subtle Decorative Ambient Glows */}
          <div className="absolute -right-8 -bottom-8 w-28 h-28 bg-amber-400/20 rounded-full blur-xl pointer-events-none group-hover:scale-125 transition-transform" />

          {/* Top Row: Tag & Mini Action Button */}
          <div className="relative z-10 flex items-center justify-between w-full">
            <span className="inline-flex items-center gap-1 text-[9.5px] font-black uppercase tracking-wider bg-white/20 backdrop-blur-xs text-amber-200 px-2 py-0.5 rounded-full border border-white/20">
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-ping" />
              CIVIC ALERT
            </span>
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-white text-[#9a3412] flex items-center justify-center shadow-xs group-hover:scale-105 group-hover:rotate-6 transition-all">
              <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
            </div>
          </div>

          {/* Text Content */}
          <div className="relative z-10 space-y-1 my-1">
            <h2 className="text-sm sm:text-base font-black tracking-tight text-white leading-tight">
              Predictive Alerts
            </h2>
            <p className="text-[11px] text-amber-100/90 leading-snug line-clamp-2">
              Upcoming season hazards & prevention guide.
            </p>
          </div>

          {/* Bottom Footer Line */}
          <div className="relative z-10 flex items-center justify-between pt-1.5 border-t border-white/15 text-[10.5px] font-bold text-amber-200">
            <span>Monsoon: 91% Risk</span>
            <span className="group-hover:translate-x-0.5 transition-transform">View →</span>
          </div>
        </button>
      </div>

      {/* ========================================================= */}
      {/* 2. CORE CIVIC TILES (2x2 BENTO GRID - CLEAN & ATTRACTIVE) */}
      {/* ========================================================= */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-black uppercase tracking-wider text-[#64748B]">
            Civic Activities & Intel
          </span>
          <span className="text-[11px] font-semibold text-[#0f2d59]">
            Explore Hub
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:gap-3.5">
          {/* Tile 1: Civic Games & Quizzes */}
          <button
            type="button"
            onClick={() => navigate('/games')}
            className="text-left bg-white rounded-3xl p-4 border border-[#cbd5e1] shadow-xs hover:shadow-md hover:border-amber-400/50 active:scale-[0.98] transition-all duration-300 group cursor-pointer flex flex-col justify-between space-y-3 relative overflow-hidden focus:outline-none"
          >
            {/* Accent colored top hairline */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-400 to-orange-500" />

            <div className="space-y-2.5 w-full">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-500 text-white flex items-center justify-center shadow-sm shadow-amber-500/25 group-hover:scale-105 transition-transform">
                  <Gamepad2 className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-extrabold text-amber-900 bg-amber-50 border border-amber-200/80 px-2 py-0.5 rounded-full">
                  +40 pts
                </span>
              </div>

              <div>
                <h3 className="text-sm font-extrabold text-[#0F172A] group-hover:text-amber-800 transition-colors leading-tight">
                  Civic Quizzes
                </h3>
                <p className="text-[11px] text-[#64748B] mt-0.5 leading-snug line-clamp-2">
                  Test your waste and water conservation instincts.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px] font-bold text-amber-700 w-full">
              <span>Play Quiz</span>
              <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </div>
          </button>

          {/* Tile 2: Report & Analysis */}
          <button
            type="button"
            onClick={() => navigate('/report-analysis')}
            className="text-left bg-white rounded-3xl p-4 border border-[#cbd5e1] shadow-xs hover:shadow-md hover:border-blue-400/50 active:scale-[0.98] transition-all duration-300 group cursor-pointer flex flex-col justify-between space-y-3 relative overflow-hidden focus:outline-none"
          >
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 to-indigo-600" />

            <div className="space-y-2.5 w-full">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-sm shadow-blue-500/25 group-hover:scale-105 transition-transform">
                  <BarChart3 className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-extrabold text-blue-900 bg-blue-50 border border-blue-200/80 px-2 py-0.5 rounded-full">
                  85% Solved
                </span>
              </div>

              <div>
                <h3 className="text-sm font-extrabold text-[#0F172A] group-hover:text-blue-800 transition-colors leading-tight">
                  Ward Analytics
                </h3>
                <p className="text-[11px] text-[#64748B] mt-0.5 leading-snug line-clamp-2">
                  Inspect hazard timelines and municipal resolution notes.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px] font-bold text-blue-700 w-full">
              <span>View Stats</span>
              <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </div>
          </button>

          {/* Tile 3: Learn & Certify */}
          <button
            type="button"
            onClick={() => navigate('/learn-certify')}
            className="text-left bg-white rounded-3xl p-4 border border-[#cbd5e1] shadow-xs hover:shadow-md hover:border-teal-400/50 active:scale-[0.98] transition-all duration-300 group cursor-pointer flex flex-col justify-between space-y-3 relative overflow-hidden focus:outline-none"
          >
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-teal-500 to-emerald-600" />

            <div className="space-y-2.5 w-full">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-teal-600 to-emerald-600 text-white flex items-center justify-center shadow-sm shadow-teal-500/25 group-hover:scale-105 transition-transform">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-extrabold text-teal-900 bg-teal-50 border border-teal-200/80 px-2 py-0.5 rounded-full">
                  3 Modules
                </span>
              </div>

              <div>
                <h3 className="text-sm font-extrabold text-[#0F172A] group-hover:text-teal-800 transition-colors leading-tight">
                  Civic Academy
                </h3>
                <p className="text-[11px] text-[#64748B] mt-0.5 leading-snug line-clamp-2">
                  Official municipal modules on RTI, safety & cleanliness.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px] font-bold text-teal-700 w-full">
              <span>Start Learning</span>
              <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </div>
          </button>

          {/* Tile 4: Rewards & Certificates */}
          <button
            type="button"
            onClick={() => navigate('/rewards')}
            className="text-left bg-white rounded-3xl p-4 border border-[#cbd5e1] shadow-xs hover:shadow-md hover:border-purple-400/50 active:scale-[0.98] transition-all duration-300 group cursor-pointer flex flex-col justify-between space-y-3 relative overflow-hidden focus:outline-none"
          >
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-500 to-violet-600" />

            <div className="space-y-2.5 w-full">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-purple-600 to-indigo-600 text-white flex items-center justify-center shadow-sm shadow-purple-500/25 group-hover:scale-105 transition-transform">
                  <Award className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-extrabold text-purple-900 bg-purple-50 border border-purple-200/80 px-2 py-0.5 rounded-full">
                  {unlockedBadgesCount} Badges
                </span>
              </div>

              <div>
                <h3 className="text-sm font-extrabold text-[#0F172A] group-hover:text-purple-800 transition-colors leading-tight">
                  Rewards & Certs
                </h3>
                <p className="text-[11px] text-[#64748B] mt-0.5 leading-snug line-clamp-2">
                  Level gauges, redeemable points, and verified credentials.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px] font-bold text-purple-700 w-full">
              <span>View Honors</span>
              <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
